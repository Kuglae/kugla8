﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;


namespace MagicnaKuglaOsam
{

    public partial class Form1 : Form
    { 
        int br = 0;
        Random rnd = new Random();
        List<string> Odgovori = new List< string >();
        public Form1()
        {
            InitializeComponent();
            Odgovori.Add("Da");
            Odgovori.Add("Definitivno");
            Odgovori.Add("Bez Sumnje");
            Odgovori.Add("To Je Definitivno");
            Odgovori.Add("Da, Definitivno");
            Odgovori.Add("Sigurno, Što Da Ne");
            Odgovori.Add("Kako Ja To Vidim, Da");
            Odgovori.Add("Najverovatnije");
            Odgovori.Add("Izgleda Dobro");
            Odgovori.Add("Znakovi Ukazuju Na Da");
            Odgovori.Add("Pitajte Ponovo Kasnije");
            Odgovori.Add("Odgovor Mutan, Pokušaj Ponovo");
            Odgovori.Add("Bolje Da Ti Ne Govorim Sada");
            Odgovori.Add("Ne Mogu Sada Predvideti");
            Odgovori.Add("Koncentriši Se i Pitaj Ponovo");
            Odgovori.Add("Ne Računaj Na To");
            Odgovori.Add("Moj Odgovor Je Ne");
            Odgovori.Add("Moji Izvori Kažu Ne");
            Odgovori.Add("Ne Izgleda Tako dobro");
            Odgovori.Add("Sumnjam");
            Odgovori.Add("Pitaj Filipa");


        }

        private void button1_Click(object sender, EventArgs e)
        {
            Da.Visible = false;
            Srednje.Visible = false;
            Upitnik.Visible = true;
            Tajmerica.Start();
            int i = rnd.Next(Odgovori.Count);
            if (i == 0) {
                Da.Visible = true;
            }
            else
            {
                Srednje.Text = Odgovori[i];
                Srednje.Visible = true;
            }


        }

        private void Tajmerica_Tick(object sender, EventArgs e)
        {
            br++;
            if (br == 3)
            {
                Upitnik.Visible = false;
                br = 0;
                Tajmerica.Stop();
            }
        }
    }
}
