﻿
namespace MagicnaKuglaOsam
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.Upitnik = new System.Windows.Forms.Label();
            this.Tajmerica = new System.Windows.Forms.Timer(this.components);
            this.Da = new System.Windows.Forms.Label();
            this.Srednje = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.InfoText;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button1.Font = new System.Drawing.Font("Parry Hotter", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button1.Location = new System.Drawing.Point(12, 497);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(209, 51);
            this.button1.TabIndex = 0;
            this.button1.Text = "Postavi Pitanje";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(3, 459);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(254, 29);
            this.textBox1.TabIndex = 1;
            this.textBox1.Text = "Unesite Pitanje ovde!";
            // 
            // Upitnik
            // 
            this.Upitnik.BackColor = System.Drawing.Color.Transparent;
            this.Upitnik.Font = new System.Drawing.Font("Comic Sans MS", 72F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Upitnik.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Upitnik.Location = new System.Drawing.Point(355, 170);
            this.Upitnik.Name = "Upitnik";
            this.Upitnik.Size = new System.Drawing.Size(206, 190);
            this.Upitnik.TabIndex = 2;
            this.Upitnik.Text = "?";
            this.Upitnik.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Upitnik.Visible = false;
            // 
            // Tajmerica
            // 
            this.Tajmerica.Interval = 1000;
            this.Tajmerica.Tick += new System.EventHandler(this.Tajmerica_Tick);
            // 
            // Da
            // 
            this.Da.BackColor = System.Drawing.Color.Transparent;
            this.Da.Font = new System.Drawing.Font("Comic Sans MS", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Da.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Da.Location = new System.Drawing.Point(391, 219);
            this.Da.Name = "Da";
            this.Da.Size = new System.Drawing.Size(118, 107);
            this.Da.TabIndex = 3;
            this.Da.Text = "Da";
            this.Da.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Da.Visible = false;
            // 
            // Srednje
            // 
            this.Srednje.BackColor = System.Drawing.Color.Transparent;
            this.Srednje.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Srednje.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Srednje.Location = new System.Drawing.Point(383, 170);
            this.Srednje.Name = "Srednje";
            this.Srednje.Size = new System.Drawing.Size(137, 181);
            this.Srednje.TabIndex = 4;
            this.Srednje.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Srednje.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(897, 553);
            this.Controls.Add(this.Srednje);
            this.Controls.Add(this.Da);
            this.Controls.Add(this.Upitnik);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button1);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(913, 592);
            this.MinimumSize = new System.Drawing.Size(913, 592);
            this.Name = "Form1";
            this.Text = "Magicna Kugla Osam";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label Upitnik;
        private System.Windows.Forms.Timer Tajmerica;
        private System.Windows.Forms.Label Da;
        private System.Windows.Forms.Label Srednje;
    }
}

